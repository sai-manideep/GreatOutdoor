package com.capgemini.gos;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class GreatOutdoorApplication {
	public static void main(String[] args) {
		SpringApplication.run(GreatOutdoorApplication.class, args);
	}
}






 










