package com.capgemini.gos.exceptions;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;



@ControllerAdvice
@ResponseBody
public class GlobalExceptionHandler {


	@ExceptionHandler(value= {AddressNotFound.class})
	public ResponseEntity<ErrorMessage> handleException1(AddressNotFound ex) {
		ErrorMessage exceptionresponse= new ErrorMessage(ex.getMessage(), " Something went wrong, please enter correct details");
		return new ResponseEntity<>(exceptionresponse,HttpStatus.BAD_REQUEST);
	}	

	@ExceptionHandler(value= {Exception.class})
	public ResponseEntity<ErrorMessage> handleException(Exception ex) {
		ErrorMessage exceptionresponse= new ErrorMessage(ex.getMessage(), " Something went wrong, please enter correct details");
		return new ResponseEntity<>(exceptionresponse,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	

		
}
