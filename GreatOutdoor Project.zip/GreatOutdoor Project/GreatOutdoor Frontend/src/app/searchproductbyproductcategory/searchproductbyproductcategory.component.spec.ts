import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchproductbyproductcategoryComponent } from './searchproductbyproductcategory.component';

describe('SearchproductbyproductcategoryComponent', () => {
  let component: SearchproductbyproductcategoryComponent;
  let fixture: ComponentFixture<SearchproductbyproductcategoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchproductbyproductcategoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchproductbyproductcategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
