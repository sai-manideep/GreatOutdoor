import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Products, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-searchproductbyproductcategory',
  templateUrl: './searchproductbyproductcategory.component.html',
  styleUrls: ['./searchproductbyproductcategory.component.css']
})
export class SearchproductbyproductcategoryComponent implements OnInit {

  productCategory:string;
  search:boolean=false;
  search1:boolean=false;
  Product:any;
  private router: Router
  constructor(private myservice: MyserviceService, router: Router) {
    this.router=router;
  }
  ngOnInit(): any {
  }
  getStatus(){
    this.myservice.searchproductByproductcategory(this.productCategory).subscribe((data)=>this.Product=data);
    
      this.search= true;
    }
  }