import { Component, OnInit } from '@angular/core';
import { Products, MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-listproduct',
  templateUrl: './listproduct.component.html',
  styleUrls: ['./listproduct.component.css']
})
export class ListproductComponent implements OnInit {

  message: string;
  products: Products[];
  constructor(private myservice: MyserviceService, public router: Router) { }

  ngOnInit(): any { 
    this.myservice.getProducts().subscribe(
    response => this.handleSuccessfulResponse(response),
  );
  }
  handleSuccessfulResponse(response) {
    console.log(response);
    this.products = response;
  }
}
